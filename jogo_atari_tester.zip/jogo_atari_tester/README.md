# jogo_atari

-Desenvolvido em C jogo de tiro com canhão para destruir objeto alvo.

# metodo para compilar

`````
gcc -o atari atari.c funcoes.c conio_v3.2.4.c -Wall -pedantic -Wextra -Werror 
`````

- versão 2

`````
gcc -o atari_v2 atari_v2.c funcoes.c conio_v3.2.4.c -Wall -pedantic -Wextra -Werror 
`````

- como usar:

* tabua esquerda teclas A e Z

* tabua direita Teclas UP e DOWN