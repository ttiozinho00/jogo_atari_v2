/*
* gcc -o atari.exe atari.c conio_v3.2.4.c funcoes.c -Wall -pedantic -Wextra -Werror
*/

/* 
   Programa: Jogo Atari v2 (Estilo Pong)
   Descri��o: Este programa implementa um jogo estilo Pong, onde dois jogadores controlam tabuas para 
              rebater uma bola que se move pela tela. O objetivo � evitar que a bola ultrapasse a tabua 
              do seu lado, pontuando quando isso acontece. A movimenta��o da bola e das tabuas s�o baseadas 
              em entradas do teclado e o jogo � exibido em um console de texto.

   Funcionalidades:
   - Controla duas tabuas que podem ser movidas para cima ou para baixo com as teclas de dire��o.
   - A bola se move automaticamente e pode colidir com as bordas da tela e com as tabuas.
   - A velocidade da bola pode ser ajustada.
   - O jogo continua em loop at� ser interrompido manualmente.

   Exemplos de uso:
   - Ativar o programa: Executar o arquivo `atari.exe` no terminal.
   - O jogo sera iniciado automaticamente, e as tabuas podem ser controladas com as teclas de dire��o.
   
   Observa��es:
   - O programa depende da biblioteca `conio_v3.2.4.h` para manipula��o de elementos graficos no console e `funcoes.h` 
     para fun��es auxiliares como a movimenta��o da bola e das tabuas.
   - O jogo e exibido em um console de texto, e n�o possui uma interface grafica.
   - A velocidade da bola pode ser controlada atraves da variavel `vel_bola`, definida em `funcoes.h`.

   Programador: [Irvna Maria Costa Soares]
   RGM: [49115]
   Data da �ltima modifica��o: [18/11/2024]
*/

/*atari_v2.c*/
#include <stdio.h>       /* printf() */
#include <stdlib.h>      /* system() */
#include <time.h>        /* time(), srand() */
#include <windows.h>     /* Sleep() */
#include "funcoes.h"     /* Declarações das funções */


int main(int argc, char const *argv[])
{
    argv = argv;
    argc = argc;
    
	srand(time(NULL));
    ocultar_cursor();
    inicializar_arena();

    while (1) 
    {
        desenhar_arena(); /*Exibe a arena no console*/ 
        movimento_tabuas(); /*Move as t�buas com base nas teclas pressionadas*/ 
        movimento_bola();  /*Move a bola e verifica colis�es*/
        Sleep(vel_bola); /*Controla a velocidade da bola*/ 
    }

	return 0;
}
