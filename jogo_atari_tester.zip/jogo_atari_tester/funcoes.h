/*funcoes.h*/
#ifndef FUNCOES_H
#define FUNCOES_H

/* Constantes */
#define LINHAS 20
#define COLUNAS 40

/* Variáveis globais */
extern unsigned char arena[LINHAS][COLUNAS];
extern int tabu_esq, tabu_dir;
extern int bola_x, bola_y;
extern int dx, dy;
extern int vel_tabu, vel_bola;

/* Protótipos das funções */
void ocultar_cursor();
void posicao_cursor(int x, int y);
void cor_texto(int cor);
void inicializar_arena();
void desenhar_arena();
void movimento_tabuas();
void movimento_bola();

#endif
