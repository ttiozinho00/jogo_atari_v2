#include <stdio.h>       /* printf(), putch() */
#include <stdlib.h>      /* exit() */
#include <time.h>        /* time(), rand() */
#include <windows.h>     /* Beep(), Sleep() */

#include "conio_v3.2.4.h" /* Fun��es de console (_setcursortype(), gotoxy()) */
#include "funcoes.h"     /* Declara��es das fun��es */

/* Vari�veis globais */
unsigned char arena[LINHAS][COLUNAS]; /* Representa a arena do jogo */
int tabu_esq, tabu_dir;             /* Posi��es das t�buas esquerda e direita */
int bola_x, bola_y;                   /* Posi��o da bola */
int dx, dy;                           /* Dire��o da bola */
int vel_tabu = 100, vel_bola = 100;   /* Velocidades das t�buas e da bola */

/*Constantes */
#define LINHAS 20
#define COLUNAS 40
#define BURACO 8


/* Esconde o cursor do console */
void ocultar_cursor() 
{
    _setcursortype(_NOCURSOR);
}

/* Move o cursor do console para uma posi��o espec�fica */
void posicao_cursor(int x, int y) 
{
    COORD coord;
    coord.X = y;
    coord.Y = x;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

/* Altera a cor do texto exibido no console */ 
void cor_texto(int cor) 
{
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), cor);
}

/*Fun��o para inicializar a arena*/ 
void inicializar_arena() 
{
	int i;
	int j;

	/*Preenche a matriz da arena com bordas e espa�os*/
    for (i = 0; i < LINHAS; i++) /*define altura*/
    {
        for (j = 0; j < COLUNAS; j++) /*define largura*/
        {
            if (i == 0 && j == 0)
			{
				arena[i][j] = '�'; /*Borda superior direita*/
			}
			if (i == LINHAS - 1 && j == 0)
			{
				arena[i][j] = '�'; /*Borda inferior direita*/
			}
			if (i == 0 && j == COLUNAS - 1)
			{
				arena[i][j] = '�'; /*Borda superior esquerda*/
			}
			if (i == LINHAS - 1 && j == COLUNAS - 1)
			{	
				arena[i][j] = '�'; /*borda inferior esquerda*/
			}	
			if((i == 0 || i == LINHAS - 1) && j > 0 && j < COLUNAS - 1)
			{
				arena[i][j] = '�'; /*Parede de cima e de baixo*/
			}
			if(((i > 0 && i < 6) || (i > 13 && i < LINHAS - 1)) && (j == 0 || j == COLUNAS - 1))
			{
				arena[i][j] = '�'; /*Parede das laterais (esquerda e direita)*/
			}
			if((i >= 6 && i <=13) && (j == 0 || j == COLUNAS - 1))
			{
				arena[i][j] = ' '; /*Buraco*/
			}
        }
    }
	/*Configura posi��es iniciais das t�buas e da bola*/
    tabu_esq = 8;
    tabu_dir = 8;
    bola_x = 10;
    bola_y = 20;
	
	/*Define dire��o inicial da bola (aleat�ria)*/ 
	/*Valores poss�veis: -1 ou 1*/ 
    dx = (rand() % 2) * 2 - 1;
    dy = (rand() % 2) * 2 - 1;
}

/* Atualiza as t�buas e a bola na matriz da arena */
void desenhar_arena() 
{
	int i;
	int j;

    posicao_cursor(0, 0);
    for (i = 0; i < LINHAS; i++) 
    {
        for (j = 0; j < COLUNAS; j++) 
        {
            if (j == 9 && i >= tabu_esq && i < tabu_esq + 3) 
            {
                cor_texto(11); /*Azul claro para a tabua esquerda*/ 
                printf("�"); /*Caractere da tabua (linha vertical)*/ 
            } 

            else if (j == COLUNAS - 11 && i >= tabu_dir && i < tabu_dir + 3) 
            {
                cor_texto(14); /*Amarelo para a tabua direita*/ 
                printf("�");
            } 

            else if (i == bola_x && j == bola_y) 
            {
                cor_texto(12); /*Vermelho para a bola*/ 
                printf("O");
            } 

            else 
            {
                cor_texto(7); /*Branco para o restante*/ 
                printf("%c", arena[i][j]);
            }
        }
        printf("\n");
    }
}

/*Fun��o para mover as t�buas*/ 
void movimento_tabuas() 
{
	/*move  a tabua para esquerda*/
    if (GetAsyncKeyState('A') & 0x8000 && tabu_esq > 1) 
    {
        tabu_esq--;
    } 

    else if (GetAsyncKeyState('Z') & 0x8000 && tabu_esq < LINHAS - 4) 
    {
        tabu_esq++;
    }
	/*move  a tabua para direita*/
    if (GetAsyncKeyState(VK_UP) & 0x8000 && tabu_dir > 1) 
    {
        tabu_dir--;
    } 

    else if (GetAsyncKeyState(VK_DOWN) & 0x8000 && tabu_dir < LINHAS - 4) 
    {
        tabu_dir++;
    }
}

/*Fun��o para mover a bola*/ 
void movimento_bola() 
{
    bola_x += dx;
    bola_y += dy;

    /** Verifica colis�o com as bordas superior e inferior (bola_y) */
    if (bola_y <= 0 || bola_y >= COLUNAS - 1) 
    {
        dy = -dy;  /** Inverte a dire��o da bola na vertical (colis�o com bordas superior ou inferior) */
        Beep(1000, 100);  /** Emite som de colis�o com a borda */
    }

    /** Verifica colis�o com a t�bua esquerda */
    if (bola_y == 1 && bola_x >= tabu_esq && bola_x < tabu_esq + 3) 
    {
        dy = -dy;  /** Inverte a dire��o da bola na horizontal (colis�o com a t�bua esquerda) */
        Beep(800, 100);  /** Emite som para a colis�o com a t�bua esquerda */
    } 

    /** Verifica colis�o com a t�bua direita */
    else if (bola_y == COLUNAS - 2 && bola_x >= tabu_dir && bola_x < tabu_dir + 3) 
    {
        dy = -dy;  /** Inverte a dire��o da bola na horizontal (colis�o com a t�bua direita) */
        Beep(800, 100);  /** Emite som para a colis�o com a t�bua direita */
    }

    /** Verifica se a bola saiu pelas laterais (fim de jogo) */
    if (bola_x <= 0 || bola_x >= LINHAS - 1) 
    {
        cor_texto(12);  /** Muda a cor do texto para vermelho para a mensagem de fim de jogo */
        printf("Fim de jogo!\nO jogador %s perdeu!\n", bola_x <= 0 ? "da esquerda" : "da direita");
        exit(0);  /** Finaliza o jogo */
    }
}